package com.example.eureaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EureaserverApplicationTests {

    @Test
    void contextLoads() {
    }

}
