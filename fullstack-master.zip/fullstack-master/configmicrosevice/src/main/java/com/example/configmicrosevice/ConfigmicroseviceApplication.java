package com.example.configmicrosevice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigmicroseviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConfigmicroseviceApplication.class, args);
    }

}
