package com.example.configmicrosevice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootTest
@EnableDiscoveryClient

class ConfigmicroseviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
