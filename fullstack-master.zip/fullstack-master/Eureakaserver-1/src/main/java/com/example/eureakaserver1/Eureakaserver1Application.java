package com.example.eureakaserver1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class Eureakaserver1Application {

    public static void main(String[] args) {
        SpringApplication.run(Eureakaserver1Application.class, args);
    }

}
